import {
  detectBrowserEnvironment,
  ext,
  setExtensionEnabled,
  uninstallExtension
} from '../shared/browser-polyfill.js';
import {
  checkRepoXpiAvailabilityForItems,
  normalizeExtensionName,
  resolveCanonicalKey,
  resolveDirectInstallTarget,
  resolveFullCatalogEntry,
  resolveRepoXpiInstallTarget,
  searchStoreAlternatives
} from '../shared/matcher.js';
import {
  getSettings,
  getSyncLogs,
  saveRemoteCache,
  saveSettings,
  touchExtensionTimestamp
} from '../shared/storage.js';
import {
  createSyncGist,
  validateTokenAndDiscoverGist
} from '../shared/gist.js';
import {
  activateGroup,
  buildInitialPayloadFromLocal,
  clearGistData,
  deleteGroup,
  enrichDashboardItemsIds,
  getDashboardState,
  isCurrentlyApplyingRemoteState,
  performSync,
  removeExtensionFromGist,
  saveEquivalentAlternative,
  saveGroup,
  saveManualBrowserIds,
  setExtensionGroups,
  toggleIgnoreKeyAndSync
} from '../shared/sync-engine.js';

const ALARM_PERIODIC_SYNC = 'ecbs-periodic-sync';
const ALARM_DEBOUNCED_SYNC = 'ecbs-debounced-sync';

/**
 * Tracks extensions initiated via "Auto Install" so when `management.onInstalled` fires:
 * 1. The temporary store/installer tab is automatically closed.
 * 2. The extension's synced enabled/disabled state (`remoteEnabled`) is automatically applied.
 */
const pendingAutoInstalls = new Map();

async function triggerAutoInstallItem(item, active = true) {
  const browserEnv = detectBrowserEnvironment();
  const target = await resolveDirectInstallTarget(
    item,
    browserEnv.family,
    browserEnv.brand
  );

  const tab = await ext.tabs.create({
    url: target.installUrl,
    active
  });

  if (item?.key) {
    pendingAutoInstalls.set(item.key, {
      key: item.key,
      name: item.name,
      ids: item.ids || {},
      remoteEnabled: item.remoteEnabled !== false,
      tabId: tab?.id || null,
      createdAt: Date.now()
    });
  }

  return target;
}

async function triggerAutoInstallFromFileItem(item, active = true) {
  const browserEnv = detectBrowserEnvironment();
  if (browserEnv.family !== 'firefox') {
    throw new Error('Auto Install from File (.xpi) is only available on Firefox.');
  }
  const settings = await getSettings();
  const target = await resolveRepoXpiInstallTarget(item, settings);

  const tab = await ext.tabs.create({
    url: target.installUrl,
    active
  });

  if (item?.key) {
    pendingAutoInstalls.set(item.key, {
      key: item.key,
      name: item.name,
      ids: item.ids || {},
      remoteEnabled: item.remoteEnabled !== false,
      tabId: tab?.id || null,
      createdAt: Date.now()
    });
  }

  return target;
}

/**
 * Updates the toolbar badge to indicate missing or out-of-sync extensions.
 */
async function refreshBadge() {
  try {
    if (!ext?.action?.setBadgeText) return;
    const state = await getDashboardState({ refreshRemote: false });
    if (!state.hasRemoteCache) {
      await ext.action.setBadgeText({ text: '' });
      return;
    }

    const { missingInLocal, stateDiff } = state.comparison.counts;
    const attentionCount = missingInLocal + stateDiff;

    if (attentionCount > 0) {
      await ext.action.setBadgeText({ text: String(attentionCount) });
      await ext.action.setBadgeBackgroundColor({
        color: stateDiff > 0 ? '#f59e0b' : '#3b82f6'
      });
    } else {
      await ext.action.setBadgeText({ text: '' });
    }
  } catch (err) {
    console.warn('Failed to update badge:', err);
  }
}

/**
 * Configures or clears the periodic background sync alarm based on settings.
 */
async function configureSyncAlarm() {
  if (!ext?.alarms) return;
  const settings = await getSettings();
  await ext.alarms.clear(ALARM_PERIODIC_SYNC);

  const minutes = Number(settings.autoSyncMinutes) || 0;
  if (minutes > 0 && settings.githubToken && settings.gistId) {
    ext.alarms.create(ALARM_PERIODIC_SYNC, {
      periodInMinutes: Math.max(1, minutes)
    });
  }
}

/**
 * Handles local management change events (enable, disable, install, uninstall).
 */
async function handleLocalExtensionChange(extInfo) {
  if (isCurrentlyApplyingRemoteState()) {
    return;
  }
  const selfId = ext.runtime?.id;
  if (extInfo?.id === selfId) return;
  if (extInfo?.type && extInfo.type !== 'extension') return;

  const settings = await getSettings();
  if (extInfo?. name) {
    const key = resolveCanonicalKey(extInfo, settings.customMappings);
    await touchExtensionTimestamp(key);
  }

  await refreshBadge();

  if (settings.autoPushOnChange && settings.githubToken && settings.gistId && ext?.alarms) {
    await ext.alarms.clear(ALARM_DEBOUNCED_SYNC);
    ext.alarms.create(ALARM_DEBOUNCED_SYNC, { delayInMinutes: 0.2 });
  }
}

// Register management listeners
if (ext?.management) {
  ext.management.onEnabled?.addListener((info) => {
    handleLocalExtensionChange(info);
  });
  ext.management.onDisabled?.addListener((info) => {
    handleLocalExtensionChange(info);
  });
  ext.management.onInstalled?.addListener(async (info) => {
    try {
      const settings = await getSettings();
      const key = resolveCanonicalKey(info, settings.customMappings);
      const normName = normalizeExtensionName(info?.name);

      let matchedPending = pendingAutoInstalls.get(key);
      if (!matchedPending) {
        for (const entry of pendingAutoInstalls.values()) {
          if (
            entry.ids?.chromium === info.id ||
            entry.ids?.firefox === info.id ||
            entry.ids?.edge === info.id ||
            (normName && normalizeExtensionName(entry.name) === normName)
          ) {
            matchedPending = entry;
            break;
          }
        }
      }

      if (matchedPending) {
        pendingAutoInstalls.delete(matchedPending.key);
        if (matchedPending.tabId && ext?.tabs?.remove) {
          try {
            await ext.tabs.remove(matchedPending.tabId);
          } catch {
            // Tab may already be closed
          }
        }
        if (matchedPending.remoteEnabled === false && info.mayDisable !== false) {
          try {
            await setExtensionEnabled(info.id, false);
          } catch (err) {
            console.warn('Failed to apply disabled state after auto-install:', err);
          }
        }
      }
    } catch (err) {
      console.warn('Error handling post-auto-install:', err);
    }

    handleLocalExtensionChange(info);
  });
  ext.management.onUninstalled?.addListener(() => {
    refreshBadge();
  });
}

// Register alarm listeners
if (ext?.alarms?.onAlarm) {
  ext.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === ALARM_PERIODIC_SYNC || alarm.name === ALARM_DEBOUNCED_SYNC) {
      const settings = await getSettings();
      if (settings.githubToken && settings.gistId) {
        try {
          await performSync({ mode: 'merge' });
          await refreshBadge();
        } catch (err) {
          console.warn('Background sync failed:', err);
        }
      }
    }
  });
}

// Initialize on install / startup
ext?.runtime?.onInstalled?.addListener(async () => {
  await configureSyncAlarm();
  await refreshBadge();
});

ext?.runtime?.onStartup?.addListener(async () => {
  await configureSyncAlarm();
  const settings = await getSettings();
  if (settings.githubToken && settings.gistId && Number(settings.autoSyncMinutes) > 0) {
    try {
      await performSync({ mode: 'merge' });
    } catch (err) {
      console.warn('Startup sync error:', err);
    }
  }
  await refreshBadge();
});

// Handle runtime messages from Popup & Options UI
ext?.runtime?.onMessage?.addListener((message, _sender, sendResponse) => {
  (async () => {
    try {
      switch (message?.type) {
        case 'GET_DASHBOARD_STATE': {
          const state = await getDashboardState({
            refreshRemote: Boolean(message.refreshRemote)
          });
          await refreshBadge();
          sendResponse({ ok: true, data: state });
          break;
        }

        case 'PERFORM_SYNC': {
          const result = await performSync({ mode: message.mode || 'merge' });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, result, data: state });
          break;
        }

        case 'TOGGLE_LOCAL_EXTENSION': {
          const { id, key, enabled } = message;
          await setExtensionEnabled(id, enabled);
          if (key) {
            await touchExtensionTimestamp(key);
          }
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, data: state });
          break;
        }

        case 'UNINSTALL_LOCAL_EXTENSION': {
          await uninstallExtension(message.id);
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, data: state });
          break;
        }

        case 'AUTO_INSTALL_EXTENSION': {
          const target = await triggerAutoInstallItem(message.item, true);
          sendResponse({ ok: true, target });
          break;
        }

        case 'AUTO_INSTALL_FROM_FILE': {
          const target = await triggerAutoInstallFromFileItem(message.item, true);
          sendResponse({ ok: true, target });
          break;
        }

        case 'AUTO_INSTALL_ALL_MISSING': {
          const items = Array.isArray(message.items) ? message.items : [];
          const results = [];
          for (let i = 0; i < items.length; i++) {
            const target = await triggerAutoInstallItem(items[i], i === 0);
            results.push(target);
          }
          sendResponse({ ok: true, count: results.length, results });
          break;
        }

        case 'TOGGLE_IGNORE_KEY': {
          await toggleIgnoreKeyAndSync(message.key);
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, data: state });
          break;
        }

        case 'SAVE_SETTINGS': {
          const updated = await saveSettings(message.settings || {});
          await configureSyncAlarm();
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, settings: updated, data: state });
          break;
        }

        case 'SAVE_BROWSER_IDS': {
          const savedIds = await saveManualBrowserIds({
            key: message.key,
            chromiumInput: message.chromiumInput,
            firefoxInput: message.firefoxInput,
            equivalentAlternative: message.equivalentAlternative,
            alternativeName: message.alternativeName
          });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, savedIds, data: state });
          break;
        }

        case 'SAVE_EQUIVALENT_ALTERNATIVE': {
          const savedAlternative = await saveEquivalentAlternative({
            key: message.key,
            targetFamily: message.targetFamily,
            alternativeInput: message.alternativeInput,
            alternativeName: message.alternativeName,
            mergeSourceKey: message.mergeSourceKey,
            mergeSourceLocalId: message.mergeSourceLocalId,
            clearAlternative: Boolean(message.clearAlternative)
          });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, savedAlternative, data: state });
          break;
        }

        case 'SEARCH_STORE_ALTERNATIVES': {
          const results = await searchStoreAlternatives(message.query, message.family);
          sendResponse({ ok: true, results });
          break;
        }

        case 'VALIDATE_AND_DISCOVER_GIST': {
          const info = await validateTokenAndDiscoverGist(message.token);
          sendResponse({ ok: true, info });
          break;
        }

        case 'CREATE_GIST': {
          const token = message.token;
          const initialPayload = await buildInitialPayloadFromLocal();
          const created = await createSyncGist(token, initialPayload);
          await saveSettings({
            githubToken: token,
            gistId: created.gistId
          });
          await saveRemoteCache(created.payload);
          await configureSyncAlarm();
          await refreshBadge();
          sendResponse({ ok: true, created });
          break;
        }

        case 'CLEAR_GIST_DATA': {
          await clearGistData({
            token: message.token,
            gistId: message.gistId
          });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, data: state });
          break;
        }

        case 'REMOVE_FROM_GIST': {
          await removeExtensionFromGist({
            key: message.key,
            name: message.name
          });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, data: state });
          break;
        }

        case 'IMPORT_PAYLOAD_CACHE': {
          await saveRemoteCache(message.payload);
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, data: state });
          break;
        }

        case 'GET_SYNC_LOGS': {
          const logs = await getSyncLogs();
          sendResponse({ ok: true, logs });
          break;
        }

        case 'RESOLVE_CATALOG_SNIPPET': {
          const resolved = await resolveFullCatalogEntry(message.item);
          sendResponse({ ok: true, ...resolved });
          break;
        }

        case 'ENRICH_DASHBOARD_IDS': {
          const changed = await enrichDashboardItemsIds(message.items || []);
          const state = changed ? await getDashboardState({ refreshRemote: false }) : null;
          sendResponse({ ok: true, changed, data: state });
          break;
        }

        case 'CHECK_REPO_XPI_AVAILABILITY': {
          const browserEnv = detectBrowserEnvironment();
          if (browserEnv.family !== 'firefox') {
            sendResponse({ ok: true, availableByKey: {} });
            break;
          }
          const settings = await getSettings();
          const availableByKey = await checkRepoXpiAvailabilityForItems(
            message.items || [],
            settings
          );
          sendResponse({ ok: true, availableByKey });
          break;
        }

        case 'ACTIVATE_GROUP': {
          const result = await activateGroup({
            groupId: message.groupId,
            active: message.active
          });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, result, data: state });
          break;
        }

        case 'SAVE_GROUP': {
          const savedGroup = await saveGroup({
            id: message.id,
            name: message.name,
            color: message.color
          });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, savedGroup, data: state });
          break;
        }

        case 'DELETE_GROUP': {
          const deleted = await deleteGroup(message.groupId);
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, deleted, data: state });
          break;
        }

        case 'SET_EXTENSION_GROUPS': {
          const updated = await setExtensionGroups({
            key: message.key,
            groupIds: message.groupIds
          });
          const state = await getDashboardState({ refreshRemote: false });
          await refreshBadge();
          sendResponse({ ok: true, updated, data: state });
          break;
        }

        default:
          sendResponse({ ok: false, error: `Unknown message type: ${message?.type}` });
      }
    } catch (error) {
      sendResponse({
        ok: false,
        error: error?.message || String(error)
      });
    }
  })();

  // Return true to keep the message channel open for async response
  return true;
});

