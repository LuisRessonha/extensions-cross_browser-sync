import { ext } from '../shared/browser-polyfill.js';
import { buildInitialPayloadFromLocal } from '../shared/sync-engine.js';
import { normalizeSyncPayload } from '../shared/gist.js';
import {
  buildCatalogEntry,
  findCatalogEntry,
  formatCatalogEntrySnippet,
  getCachedExtensionIconUrl,
  getStoreInstallInfo,
  parseGitRepoUrl,
  resolveExtensionIconUrl
} from '../shared/matcher.js';

let currentState = null;
let activeMatrixFilter = 'all';
let activeGroupFilter = 'all';
let editingGroupId = null;
let availableXpiByKey = {};
let xpiCheckPromise = null;
let activeAlternativeItem = null;

const els = {
  envBadge: document.getElementById('env-badge'),
  headerSyncBtn: document.getElementById('header-sync-btn'),
  headerPushBtn: document.getElementById('header-push-btn'),
  headerPullBtn: document.getElementById('header-pull-btn'),
  openSettingsModalBtn: document.getElementById('open-settings-modal-btn'),
  closeSettingsModalBtn: document.getElementById('close-settings-modal-btn'),
  settingsModal: document.getElementById('settings-modal'),
  catalogJsonModal: document.getElementById('catalog-json-modal'),
  catalogJsonModalTitle: document.getElementById('catalog-json-modal-title'),
  catalogJsonPre: document.getElementById('catalog-json-pre'),
  closeCatalogJsonModalBtn: document.getElementById('close-catalog-json-modal-btn'),
  copyCatalogJsonBtn: document.getElementById('copy-catalog-json-btn'),
  matchAlternativeModal: document.getElementById('match-alternative-modal'),
  matchAlternativeModalTitle: document.getElementById('match-alternative-modal-title'),
  altModalDesc: document.getElementById('alt-modal-desc'),
  closeAlternativeModalBtn: document.getElementById('close-alternative-modal-btn'),
  altTargetFamily: document.getElementById('alt-target-family'),
  altExistingSelect: document.getElementById('alt-existing-select'),
  altStoreSearchInput: document.getElementById('alt-store-search-input'),
  altStoreSearchBtn: document.getElementById('alt-store-search-btn'),
  altStoreResults: document.getElementById('alt-store-results'),
  altIdInput: document.getElementById('alt-id-input'),
  altNameInput: document.getElementById('alt-name-input'),
  clearAlternativeBtn: document.getElementById('clear-alternative-btn'),
  cancelAlternativeBtn: document.getElementById('cancel-alternative-btn'),
  saveAlternativeBtn: document.getElementById('save-alternative-btn'),
  groupsBarList: document.getElementById('groups-bar-list'),
  openGroupsModalBtn: document.getElementById('open-groups-modal-btn'),
  manageGroupsModal: document.getElementById('manage-groups-modal'),
  closeGroupsModalBtn: document.getElementById('close-groups-modal-btn'),
  groupFormLabel: document.getElementById('group-form-label'),
  newGroupNameInput: document.getElementById('new-group-name-input'),
  newGroupColorInput: document.getElementById('new-group-color-input'),
  saveGroupBtn: document.getElementById('save-group-btn'),
  cancelEditGroupBtn: document.getElementById('cancel-edit-group-btn'),
  manageGroupsList: document.getElementById('manage-groups-list'),
  alertBanner: document.getElementById('alert-banner'),
  githubToken: document.getElementById('github-token'),
  toggleTokenBtn: document.getElementById('toggle-token-btn'),
  discoverGistBtn: document.getElementById('discover-gist-btn'),
  createGistBtn: document.getElementById('create-gist-btn'),
  gistId: document.getElementById('gist-id'),
  openGistLink: document.getElementById('open-gist-link'),
  deviceName: document.getElementById('device-name'),
  gitRepoUrl: document.getElementById('git-repo-url'),
  gitRepoToken: document.getElementById('git-repo-token'),
  toggleRepoTokenBtn: document.getElementById('toggle-repo-token-btn'),
  gitRepoBranch: document.getElementById('git-repo-branch'),
  openRepoLink: document.getElementById('open-repo-link'),
  saveGistBtn: document.getElementById('save-gist-btn'),
  clearGistBtn: document.getElementById('clear-gist-btn'),
  autoSyncMinutes: document.getElementById('auto-sync-minutes'),
  autoPushOnChange: document.getElementById('auto-push-on-change'),
  autoApplyEnabled: document.getElementById('auto-apply-enabled'),
  syncDisabledExtensions: document.getElementById('sync-disabled-extensions'),
  includeDevExtensions: document.getElementById('include-dev-extensions'),
  exclusiveGroupActivation: document.getElementById('exclusive-group-activation'),
  syncActiveGroupsGist: document.getElementById('sync-active-groups-gist'),
  savePrefsBtn: document.getElementById('save-prefs-btn'),
  exportSettingsBtn: document.getElementById('export-settings-btn'),
  importSettingsInput: document.getElementById('import-settings-input'),
  exportJsonBtn: document.getElementById('export-json-btn'),
  importJsonInput: document.getElementById('import-json-input'),
  syncLogList: document.getElementById('sync-log-list'),
  matrixStats: document.getElementById('matrix-stats'),
  matrixSearch: document.getElementById('matrix-search'),
  matrixInstallMissingBtn: document.getElementById('matrix-install-missing-btn'),
  refreshRemoteBtn: document.getElementById('refresh-remote-btn'),
  matrixTbody: document.getElementById('matrix-tbody')
};

function sendMessage(msg) {
  return new Promise((resolve, reject) => {
    ext.runtime.sendMessage(msg, (response) => {
      const err = ext.runtime.lastError;
      if (err) {
        reject(new Error(err.message));
        return;
      }
      if (!response?.ok) {
        reject(new Error(response?.error || 'Operation failed'));
        return;
      }
      resolve(response);
    });
  });
}

function showAlert(message, isError = false) {
  els.alertBanner.textContent = message;
  els.alertBanner.classList.remove('hidden', 'error');
  if (isError) {
    els.alertBanner.classList.add('error');
  }
  clearTimeout(showAlert._timer);
  showAlert._timer = setTimeout(() => {
    els.alertBanner.classList.add('hidden');
  }, 6000);
}

function updateGistLink(gistId) {
  if (gistId && gistId.trim()) {
    els.openGistLink.href = `https://gist.github.com/${encodeURIComponent(gistId.trim())}`;
    els.openGistLink.classList.remove('hidden');
  } else {
    els.openGistLink.classList.add('hidden');
  }
}

function updateRepoLink(repoUrl) {
  const parsed = parseGitRepoUrl(repoUrl || '');
  if (parsed?.owner && parsed?.repo) {
    els.openRepoLink.href = `https://github.com/${encodeURIComponent(parsed.owner)}/${encodeURIComponent(parsed.repo)}`;
    els.openRepoLink.classList.remove('hidden');
  } else {
    els.openRepoLink.classList.add('hidden');
  }
}

function createFallbackBadge(name) {
  const fb = document.createElement('div');
  fb.className = 'cell-fallback';
  fb.textContent = (name || '?').trim().charAt(0).toUpperCase();
  return fb;
}

function createMatrixIconElement(item) {
  const cachedIconUrl = getCachedExtensionIconUrl(item);
  const isMozExtUrl = Boolean(item.iconUrl && item.iconUrl.startsWith('moz-extension://'));
  const initialSrc = cachedIconUrl || (!isMozExtUrl ? item.iconUrl : '') || item.iconUrl || '';

  const fallbackAndResolve = (currentEl) => {
    const fb = createFallbackBadge(item.name);
    if (currentEl?.parentNode) {
      currentEl.replaceWith(fb);
    }
    resolveExtensionIconUrl(item)
      .then((resolvedUrl) => {
        if (resolvedUrl && fb.parentNode) {
          const resolvedImg = document.createElement('img');
          resolvedImg.className = 'cell-icon';
          resolvedImg.src = resolvedUrl;
          resolvedImg.alt = '';
          resolvedImg.addEventListener('error', () => {
            if (resolvedImg.parentNode) {
              resolvedImg.replaceWith(createFallbackBadge(item.name));
            }
          });
          fb.replaceWith(resolvedImg);
        }
      })
      .catch(() => {});
    return fb;
  };

  if (initialSrc) {
    const img = document.createElement('img');
    img.className = 'cell-icon';
    img.src = initialSrc;
    img.alt = '';
    img.addEventListener('error', () => {
      fallbackAndResolve(img);
    });
    return img;
  }

  return fallbackAndResolve(null);
}

async function refreshXpiAvailability() {
  if (currentState?.browserEnv?.family !== 'firefox') {
    availableXpiByKey = {};
    return;
  }
  const missingItems = (currentState?.comparison?.items || []).filter(
    (i) => i.status === 'missing'
  );
  if (missingItems.length === 0) {
    availableXpiByKey = {};
    return;
  }
  const promise = (async () => {
    try {
      const res = await sendMessage({
        type: 'CHECK_REPO_XPI_AVAILABILITY',
        items: missingItems
      });
      availableXpiByKey = res?.availableByKey || {};
      renderMatrix();
    } catch {
      availableXpiByKey = {};
    }
  })();
  xpiCheckPromise = promise;
  await promise;
}

function populateSettingsForm(settings, browserEnv) {
  els.envBadge.textContent = `${browserEnv?.label || 'Browser'} (${browserEnv?.family || ''})`;
  els.githubToken.value = settings.githubToken || '';
  els.gistId.value = settings.gistId || '';
  els.deviceName.value = settings.deviceName || browserEnv?.label || '';
  els.gitRepoUrl.value = settings.gitRepoUrl || '';
  els.gitRepoToken.value = settings.gitRepoToken || '';
  els.gitRepoBranch.value = settings.gitRepoBranch || '';
  updateGistLink(settings.gistId);
  updateRepoLink(settings.gitRepoUrl);

  els.autoSyncMinutes.value = String(settings.autoSyncMinutes ?? 30);
  els.autoPushOnChange.checked = Boolean(settings.autoPushOnChange);
  els.autoApplyEnabled.checked = settings.autoApplyEnabledState !== false;
  els.syncDisabledExtensions.checked = settings.syncDisabledExtensions !== false;
  els.includeDevExtensions.checked = Boolean(settings.includeDevelopmentExtensions);
  if (els.exclusiveGroupActivation) {
    els.exclusiveGroupActivation.checked = settings.exclusiveGroupActivation !== false;
  }
  if (els.syncActiveGroupsGist) {
    els.syncActiveGroupsGist.checked = settings.syncActiveGroupsToGist !== false;
  }
}

function getOrderedGroups(groupsMap = {}) {
  const entries = Object.values(groupsMap);
  const def = entries.find((g) => g.id === 'default') || {
    id: 'default',
    name: 'Default',
    color: '#64748b',
    isDefault: true
  };
  const others = entries
    .filter((g) => g && g.id !== 'default')
    .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  return [def, ...others];
}

function renderGroupsBar() {
  if (!els.groupsBarList || !currentState) return;
  const { comparison, settings } = currentState;
  const items = (comparison?.items || []).filter((i) => i.status !== 'ignored');
  const groupsMap = comparison?.groups || settings?.groups || {};
  const activeGroupIds = Array.isArray(comparison?.activeGroupIds)
    ? comparison.activeGroupIds
    : Array.isArray(settings?.activeGroupIds)
    ? settings.activeGroupIds
    : [];
  const orderedGroups = getOrderedGroups(groupsMap);

  if (activeGroupFilter !== 'all' && !groupsMap[activeGroupFilter]) {
    activeGroupFilter = 'all';
  }

  els.groupsBarList.replaceChildren();

  // "All Groups" filter chip
  const allChip = document.createElement('div');
  allChip.className = `group-chip${activeGroupFilter === 'all' ? ' group-filter-selected' : ''}`;
  const allFilterBtn = document.createElement('button');
  allFilterBtn.type = 'button';
  allFilterBtn.className = 'group-chip-filter-btn';
  allFilterBtn.title = 'Show extensions from all groups';
  allFilterBtn.textContent = 'All Groups';
  allFilterBtn.addEventListener('click', () => {
    activeGroupFilter = 'all';
    renderMatrix();
  });
  allChip.appendChild(allFilterBtn);
  els.groupsBarList.appendChild(allChip);

  for (const grp of orderedGroups) {
    const extCount = items.filter((item) => (item.groups || ['default']).includes(grp.id)).length;
    const isActive = !grp.isDefault && activeGroupIds.includes(grp.id);
    const isFilterSelected = activeGroupFilter === grp.id;

    const chip = document.createElement('div');
    chip.className = `group-chip${isFilterSelected ? ' group-filter-selected' : ''}${
      isActive ? ' group-active-state' : ''
    }`;

    const filterBtn = document.createElement('button');
    filterBtn.type = 'button';
    filterBtn.className = 'group-chip-filter-btn';
    filterBtn.title = grp.isDefault
      ? `${grp.name} (${extCount}): Extensions in Default are never affected by activating or deactivating other groups. Click to filter.`
      : `${grp.name} (${extCount}): Click to filter matrix by "${grp.name}".`;

    const dot = document.createElement('span');
    dot.className = 'group-dot';
    dot.style.backgroundColor = grp.color || '#3b82f6';

    const nameSpan = document.createElement('span');
    nameSpan.textContent = grp.name;

    const countSpan = document.createElement('span');
    countSpan.className = 'group-count';
    countSpan.textContent = String(extCount);

    filterBtn.append(dot, nameSpan, countSpan);
    filterBtn.addEventListener('click', () => {
      activeGroupFilter = activeGroupFilter === grp.id ? 'all' : grp.id;
      renderMatrix();
    });
    chip.appendChild(filterBtn);

    if (!grp.isDefault) {
      const toggleBtn = document.createElement('button');
      toggleBtn.type = 'button';
      toggleBtn.className = `group-chip-toggle-btn${isActive ? ' is-active' : ''}`;
      toggleBtn.textContent = isActive ? 'ACTIVE' : 'Activate';
      toggleBtn.title = isActive
        ? `Group "${grp.name}" is currently ACTIVE. Click to deactivate.`
        : `Activate group "${grp.name}" (enables extensions in this group and disables extensions in inactive non-default groups; Default extensions stay untouched).`;
      toggleBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        try {
          toggleBtn.disabled = true;
          const res = await sendMessage({
            type: 'ACTIVATE_GROUP',
            groupId: grp.id,
            active: !isActive
          });
          currentState = res.data;
          renderMatrix();
          await refreshSyncLogs();
          const r = res.result;
          showAlert(
            !isActive
              ? `Activated group "${grp.name}" (${r?.toggledCount ?? 0} extensions toggled, ${
                  r?.untouchedDefaultCount ?? 0
                } Default untouched).`
              : `Deactivated group "${grp.name}" (${r?.toggledCount ?? 0} extensions toggled).`
          );
        } catch (err) {
          showAlert(err.message, true);
        } finally {
          toggleBtn.disabled = false;
        }
      });
      chip.appendChild(toggleBtn);
    }

    els.groupsBarList.appendChild(chip);
  }
}

function createExtensionGroupsCell(item, groupsMap) {
  const tdGroups = document.createElement('td');
  const wrap = document.createElement('div');
  wrap.className = 'cell-groups-wrap';

  const badgesRow = document.createElement('div');
  badgesRow.className = 'cell-groups-badges';

  const itemGroups =
    Array.isArray(item.groups) && item.groups.length > 0 ? item.groups : ['default'];
  const orderedGroups = getOrderedGroups(groupsMap);

  for (const gid of itemGroups) {
    const grp = groupsMap[gid] || { id: gid, name: gid, color: '#64748b', isDefault: gid === 'default' };
    const badge = document.createElement('span');
    badge.className = `group-badge${grp.isDefault ? ' group-badge-default' : ''}`;
    badge.title = grp.isDefault
      ? 'Default Group: Not affected when other groups are activated or deactivated'
      : `Belongs to group "${grp.name}"`;

    const dot = document.createElement('span');
    dot.className = 'group-dot';
    dot.style.backgroundColor = grp.color || '#3b82f6';
    const text = document.createElement('span');
    text.textContent = grp.name;
    badge.append(dot, text);
    badgesRow.appendChild(badge);
  }

  const pickerWrap = document.createElement('div');
  pickerWrap.className = 'group-picker-dropdown';

  const pickerBtn = document.createElement('button');
  pickerBtn.type = 'button';
  pickerBtn.className = 'btn btn-secondary btn-sm';
  pickerBtn.style.padding = '2px 7px';
  pickerBtn.style.fontSize = '11px';
  pickerBtn.textContent = 'Groups ▾';
  pickerBtn.title = 'Assign this extension to Default or one or more custom groups';

  const menu = document.createElement('div');
  menu.className = 'group-picker-menu hidden';
  menu.addEventListener('click', (e) => e.stopPropagation());

  for (const grp of orderedGroups) {
    const label = document.createElement('label');
    label.className = 'group-picker-option';
    label.title = grp.isDefault
      ? 'Default group (never affected by activating other groups)'
      : `Include in "${grp.name}" group`;

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = itemGroups.includes(grp.id);

    const dot = document.createElement('span');
    dot.className = 'group-dot';
    dot.style.backgroundColor = grp.color || '#3b82f6';

    const nameSpan = document.createElement('span');
    nameSpan.textContent = grp.isDefault ? `${grp.name} (Independent)` : grp.name;

    cb.addEventListener('change', async () => {
      let nextGroups;
      if (grp.isDefault) {
        if (cb.checked) {
          nextGroups = ['default'];
        } else {
          // If unchecking default without any other group selected, keep default
          const nonDefault = itemGroups.filter((g) => g !== 'default');
          nextGroups = nonDefault.length > 0 ? nonDefault : ['default'];
        }
      } else {
        const baseNonDefault = itemGroups.filter((g) => g !== 'default');
        if (cb.checked) {
          nextGroups = Array.from(new Set([...baseNonDefault, grp.id]));
        } else {
          const remaining = baseNonDefault.filter((g) => g !== grp.id);
          nextGroups = remaining.length > 0 ? remaining : ['default'];
        }
      }

      try {
        const res = await sendMessage({
          type: 'SET_EXTENSION_GROUPS',
          key: item.key,
          groupIds: nextGroups
        });
        currentState = res.data;
        renderMatrix();
      } catch (err) {
        showAlert(err.message, true);
      }
    });

    label.append(cb, dot, nameSpan);
    menu.appendChild(label);
  }

  pickerBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const wasHidden = menu.classList.contains('hidden');
    for (const openMenu of document.querySelectorAll('.install-dropdown-menu, .group-picker-menu')) {
      openMenu.classList.add('hidden');
    }
    if (wasHidden) {
      const rect = pickerBtn.getBoundingClientRect();
      if (rect.bottom + 180 > window.innerHeight) {
        menu.classList.add('drop-up');
      } else {
        menu.classList.remove('drop-up');
      }
      menu.classList.remove('hidden');
    }
  });

  pickerWrap.append(pickerBtn, menu);
  wrap.append(badgesRow, pickerWrap);
  tdGroups.appendChild(wrap);
  return tdGroups;
}

function renderMatrix() {
  if (!currentState) return;
  const { comparison, settings } = currentState;
  const { counts, items } = comparison;
  const groupsMap = comparison?.groups || settings?.groups || {};

  renderGroupsBar();

  els.matrixStats.replaceChildren();
  const nonIgnoredItems = items.filter((i) => i.status !== 'ignored');
  const installedLocalCount = nonIgnoredItems.filter((i) => Boolean(i.localId)).length;

  const statEntries = [
    {
      key: 'all',
      label: 'All',
      val: nonIgnoredItems.length,
      desc: 'Show all non-ignored extensions (both locally installed and saved in Gist)'
    },
    {
      key: 'installed',
      label: 'Installed (Local)',
      val: installedLocalCount,
      desc: 'Show extensions currently installed in this browser (excluding ignored)'
    },
    {
      key: 'state-diff',
      label: 'Out of sync',
      val: counts.stateDiff,
      desc: 'Show extensions where the local enabled/disabled state differs from the Gist state'
    },
    {
      key: 'missing',
      label: 'Missing',
      val: counts.missingInLocal,
      desc: 'Show extensions saved in your Gist that are not installed in this browser yet'
    },
    {
      key: 'ignored',
      label: 'Ignored',
      val: counts.ignored,
      desc: 'Show extensions excluded from cross-browser synchronization'
    }
  ];
  for (const { key, label, val, desc } of statEntries) {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = `stat-chip${activeMatrixFilter === key ? ' active' : ''}`;
    chip.title = desc;
    const strong = document.createElement('strong');
    strong.textContent = String(val);
    chip.append(`${label}: `, strong);
    chip.addEventListener('click', () => {
      activeMatrixFilter = key;
      renderMatrix();
    });
    els.matrixStats.appendChild(chip);
  }

  const missingItems = items.filter((i) => i.status === 'missing');
  if (missingItems.length > 0) {
    els.matrixInstallMissingBtn.classList.remove('hidden');
    els.matrixInstallMissingBtn.textContent = `Auto-Install All Missing (${missingItems.length})`;
  } else {
    els.matrixInstallMissingBtn.classList.add('hidden');
  }

  const query = els.matrixSearch.value.trim().toLowerCase();

  const filtered = items.filter((item) => {
    if (activeMatrixFilter === 'all' && item.status === 'ignored') return false;
    if (activeMatrixFilter === 'installed' && (!item.localId || item.status === 'ignored')) {
      return false;
    }
    if (activeMatrixFilter === 'state-diff' && item.status !== 'state-diff') return false;
    if (activeMatrixFilter === 'missing' && item.status !== 'missing') return false;
    if (activeMatrixFilter === 'ignored' && item.status !== 'ignored') return false;
    if (activeGroupFilter !== 'all') {
      const itemGroups =
        Array.isArray(item.groups) && item.groups.length > 0 ? item.groups : ['default'];
      if (!itemGroups.includes(activeGroupFilter)) return false;
    }
    if (query) {
      const hay = `${item.name} ${item.key} ${item.localId || ''} ${item.ids?.chromium || ''} ${
        item.ids?.firefox || ''
      }`.toLowerCase();
      if (!hay.includes(query)) return false;
    }
    return true;
  });

  els.matrixTbody.replaceChildren();

  if (filtered.length === 0) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = 7;
    td.className = 'empty-cell';
    td.textContent = 'No extensions match the current filter.';
    tr.appendChild(td);
    els.matrixTbody.appendChild(tr);
    return;
  }

  for (const item of filtered) {
    const tr = document.createElement('tr');

    // Col 1: Extension Icon + Name + Version
    const tdExt = document.createElement('td');
    const extWrap = document.createElement('div');
    extWrap.className = 'cell-ext';
    extWrap.appendChild(createMatrixIconElement(item));
    const nameBox = document.createElement('div');
    const titleEl = document.createElement('div');
    titleEl.style.fontWeight = '600';
    titleEl.textContent = item.name;
    const verEl = document.createElement('div');
    verEl.className = 'muted';
    verEl.style.fontSize = '11px';
    verEl.textContent = item.version ? `v${item.version}` : '';
    nameBox.appendChild(titleEl);
    nameBox.appendChild(verEl);
    if (item.equivalentAlternative) {
      const altBadge = document.createElement('div');
      altBadge.className = 'alt-badge';
      altBadge.textContent = item.alternativeName
        ? `≈ Equivalent: ${item.alternativeName}`
        : '≈ Equivalent Alternative';
      altBadge.title = item.alternativeName
        ? `Flagged as an Equivalent Alternative across browsers (paired with "${item.alternativeName}")`
        : 'Flagged as an Equivalent Alternative across browsers';
      nameBox.appendChild(altBadge);
    }
    extWrap.appendChild(nameBox);
    tdExt.appendChild(extWrap);

    // Col 2: Canonical Sync Key (editable for local extensions to allow custom cross-browser pairing)
    const tdKey = document.createElement('td');
    if (item.localId) {
      const wrap = document.createElement('div');
      wrap.className = 'key-input-wrap';
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'key-input';
      input.value = item.key;
      input.title =
        'Canonical key used to pair this extension across Chromium & Firefox. Edit and click Save to customize.';

      const saveKeyBtn = document.createElement('button');
      saveKeyBtn.className = 'btn btn-secondary btn-sm hidden';
      saveKeyBtn.textContent = 'Save';
      saveKeyBtn.title = 'Save custom canonical sync key for cross-browser pairing';

      input.addEventListener('input', () => {
        if (input.value.trim() && input.value.trim() !== item.key) {
          saveKeyBtn.classList.remove('hidden');
        } else {
          saveKeyBtn.classList.add('hidden');
        }
      });

      saveKeyBtn.addEventListener('click', async () => {
        const newKey = input.value.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '-');
        if (!newKey) return;
        const nextMappings = {
          ...(settings.customMappings || {}),
          [item.localId]: newKey
        };
        const res = await sendMessage({
          type: 'SAVE_SETTINGS',
          settings: { customMappings: nextMappings }
        });
        currentState = res.data;
        renderMatrix();
        showAlert(`Mapped "${item.name}" to canonical sync key "${newKey}".`);
      });

      wrap.appendChild(input);
      wrap.appendChild(saveKeyBtn);
      tdKey.appendChild(wrap);
    } else {
      const code = document.createElement('code');
      code.textContent = item.key;
      tdKey.appendChild(code);
    }

    // Col 3: Browser IDs (Chromium / Firefox / Edge) with Store links and manual edit support
    const tdIds = document.createElement('td');
    const idList = document.createElement('div');
    idList.className = 'id-list';

    const catalogEntry = findCatalogEntry({
      key: item.key,
      name: item.name,
      id: item.localId || item.ids?.chromium || item.ids?.firefox || item.ids?.edge
    });

    const initialCr = item.ids?.chromium || catalogEntry?.chromiumId || '';
    const initialFf = item.ids?.firefox || catalogEntry?.firefoxId || '';
    const initialEd = item.ids?.edge || catalogEntry?.edgeId || '';

    const itemWithAllIds = {
      ...item,
      ids: {
        ...(item.ids || {}),
        ...(initialCr ? { chromium: initialCr } : {}),
        ...(initialFf ? { firefox: initialFf } : {}),
        ...(initialEd ? { edge: initialEd } : {})
      }
    };

    const crStore = getStoreInstallInfo(itemWithAllIds, 'chromium', 'chrome');
    const ffStore = getStoreInstallInfo(itemWithAllIds, 'firefox', 'firefox');

    const crRow = document.createElement('div');
    crRow.className = 'id-edit-row';
    const crLabel = document.createElement('span');
    crLabel.className = 'id-prefix';
    crLabel.textContent = 'Cr:';
    const crInput = document.createElement('input');
    crInput.type = 'text';
    crInput.className = `id-input${!initialCr ? ' id-missing' : ''}`;
    crInput.value = initialCr;
    crInput.placeholder = 'Missing — enter Chromium ID or URL';
    crInput.title = initialCr
      ? `Chromium ID: ${initialCr} (edit or paste Chrome Web Store URL to override)`
      : 'Chromium ID not found automatically — enter 32-char ID or paste Chrome Web Store URL';
    crRow.appendChild(crLabel);
    crRow.appendChild(crInput);
    if (crStore?.isDirect && crStore.url) {
      const crStoreBtn = document.createElement('a');
      crStoreBtn.href = crStore.url;
      crStoreBtn.target = '_blank';
      crStoreBtn.rel = 'noopener';
      crStoreBtn.className = 'btn btn-secondary id-store-btn';
      crStoreBtn.textContent = 'Store ↗';
      crStoreBtn.title = `Open in ${crStore.storeName || 'Chrome Web Store'}`;
      crRow.appendChild(crStoreBtn);
    }

    const ffRow = document.createElement('div');
    ffRow.className = 'id-edit-row';
    const ffLabel = document.createElement('span');
    ffLabel.className = 'id-prefix';
    ffLabel.textContent = 'Ff:';
    const ffInput = document.createElement('input');
    ffInput.type = 'text';
    ffInput.className = `id-input${!initialFf ? ' id-missing' : ''}`;
    ffInput.value = initialFf;
    ffInput.placeholder = 'Missing — enter Firefox ID or URL';
    ffInput.title = initialFf
      ? `Firefox ID: ${initialFf} (edit or paste Firefox Add-ons URL to override)`
      : 'Firefox ID not found automatically — enter Add-on GUID/slug or paste Firefox Add-ons URL';
    ffRow.appendChild(ffLabel);
    ffRow.appendChild(ffInput);
    if (ffStore?.isDirect && ffStore.url) {
      const ffStoreBtn = document.createElement('a');
      ffStoreBtn.href = ffStore.url;
      ffStoreBtn.target = '_blank';
      ffStoreBtn.rel = 'noopener';
      ffStoreBtn.className = 'btn btn-secondary id-store-btn';
      ffStoreBtn.textContent = 'Store ↗';
      ffStoreBtn.title = `Open in ${ffStore.storeName || 'Firefox Add-ons'}`;
      ffRow.appendChild(ffStoreBtn);
    }

    idList.appendChild(crRow);
    idList.appendChild(ffRow);

    if (initialEd) {
      const edRow = document.createElement('div');
      edRow.className = 'id-edit-row';
      const edLabel = document.createElement('span');
      edLabel.className = 'id-prefix';
      edLabel.textContent = 'Ed:';
      const edInput = document.createElement('input');
      edInput.type = 'text';
      edInput.className = 'id-input';
      edInput.value = initialEd;
      edInput.readOnly = true;
      edInput.title = `Edge Add-ons ID: ${initialEd}`;
      edRow.appendChild(edLabel);
      edRow.appendChild(edInput);

      const edUrl =
        item.storeUrls?.edge ||
        `https://microsoftedge.microsoft.com/addons/detail/${encodeURIComponent(initialEd)}`;
      const edStoreBtn = document.createElement('a');
      edStoreBtn.href = edUrl;
      edStoreBtn.target = '_blank';
      edStoreBtn.rel = 'noopener';
      edStoreBtn.className = 'btn btn-secondary id-store-btn';
      edStoreBtn.textContent = 'Store ↗';
      edStoreBtn.title = 'Open in Edge Add-ons';
      edRow.appendChild(edStoreBtn);
      idList.appendChild(edRow);
    }

    const saveIdsBtn = document.createElement('button');
    saveIdsBtn.className = 'btn btn-secondary btn-sm hidden';
    saveIdsBtn.textContent = 'Save IDs';
    saveIdsBtn.title = 'Save custom Chromium and Firefox IDs or store URLs for this extension';
    saveIdsBtn.style.alignSelf = 'flex-start';

    const checkIdsDirty = () => {
      const changed =
        crInput.value.trim() !== initialCr || ffInput.value.trim() !== initialFf;
      if (changed) {
        saveIdsBtn.classList.remove('hidden');
      } else {
        saveIdsBtn.classList.add('hidden');
      }
    };

    crInput.addEventListener('input', checkIdsDirty);
    ffInput.addEventListener('input', checkIdsDirty);

    saveIdsBtn.addEventListener('click', async () => {
      try {
        saveIdsBtn.disabled = true;
        const res = await sendMessage({
          type: 'SAVE_BROWSER_IDS',
          key: item.key,
          chromiumInput: crInput.value.trim(),
          firefoxInput: ffInput.value.trim()
        });
        currentState = res.data;
        renderMatrix();
        showAlert(
          `Updated Browser IDs for "${item.name}" (Cr: ${
            res.savedIds?.chromium || 'none'
          }, Ff: ${res.savedIds?.firefox || 'none'}).`
        );
      } catch (err) {
        showAlert(err.message, true);
      } finally {
        saveIdsBtn.disabled = false;
      }
    });

    idList.appendChild(saveIdsBtn);

    if (!initialCr || !initialFf || item.equivalentAlternative) {
      const matchAltBtn = document.createElement('button');
      matchAltBtn.type = 'button';
      matchAltBtn.className = 'btn btn-sm btn-alt-match';
      matchAltBtn.textContent = item.equivalentAlternative
        ? 'Edit Alternative ⇄'
        : 'Match Alternative ⇄';
      matchAltBtn.title = item.equivalentAlternative
        ? 'Edit or unflag the matched equivalent alternative extension'
        : 'Extension is unavailable on both stores — match it with an equivalent alternative and flag it as an Equivalent Alternative';
      matchAltBtn.addEventListener('click', () => {
        openMatchAlternativeModal(item, { initialCr, initialFf });
      });
      idList.appendChild(matchAltBtn);
    }

    tdIds.appendChild(idList);

    // Col 4: Sync Status
    const tdStatus = document.createElement('td');
    const pill = document.createElement('span');
    pill.className = `pill pill-${item.status}`;
    const labels = {
      'in-sync': 'In Sync',
      'state-diff': `State Diff (Cloud: ${item.remoteEnabled ? 'ON' : 'OFF'})`,
      missing: `Missing (Cloud: ${item.remoteEnabled ? 'ON' : 'OFF'})`,
      'local-only': 'Local Only',
      ignored: 'Ignored'
    };
    pill.textContent = labels[item.status] || item.status;
    tdStatus.appendChild(pill);

    // Col 5: Local State
    const tdLocal = document.createElement('td');
    if (item.localId) {
      const toggleBtn = document.createElement('button');
      toggleBtn.className = `btn btn-sm ${item.localEnabled ? 'btn-accent' : 'btn-secondary'}`;
      toggleBtn.textContent = item.localEnabled ? 'Enabled' : 'Disabled';
      toggleBtn.disabled = !item.mayDisable;
      toggleBtn.title = !item.mayDisable
        ? 'This extension cannot be disabled'
        : item.localEnabled
        ? 'Click to disable this extension locally'
        : 'Click to enable this extension locally';
      toggleBtn.addEventListener('click', async () => {
        try {
          const res = await sendMessage({
            type: 'TOGGLE_LOCAL_EXTENSION',
            id: item.localId,
            key: item.key,
            enabled: !item.localEnabled
          });
          currentState = res.data;
          renderMatrix();
        } catch (err) {
          showAlert(err.message, true);
        }
      });
      tdLocal.appendChild(toggleBtn);
    } else {
      const span = document.createElement('span');
      span.className = 'muted';
      span.textContent = 'Not installed';
      tdLocal.appendChild(span);
    }

    // Col 6: Actions
    const tdActions = document.createElement('td');
    const actRow = document.createElement('div');
    actRow.className = 'button-row';

    if (item.status === 'missing') {
      const dropdownWrap = document.createElement('div');
      dropdownWrap.className = 'install-dropdown';

      const installTriggerBtn = document.createElement('button');
      installTriggerBtn.type = 'button';
      installTriggerBtn.className = 'btn btn-sm btn-primary';
      installTriggerBtn.textContent = 'Install ▾';
      installTriggerBtn.title = 'Choose how to install this extension';

      const menu = document.createElement('div');
      menu.className = 'install-dropdown-menu hidden';

      const autoInstallOpt = document.createElement('button');
      autoInstallOpt.type = 'button';
      autoInstallOpt.className = 'install-dropdown-item';
      autoInstallOpt.title =
        'Install this extension directly from the official browser store (Chrome Web Store / Firefox AMO)';
      const autoTitle = document.createElement('strong');
      autoTitle.textContent = 'Auto Install';
      const autoSub = document.createElement('span');
      autoSub.textContent = 'Install from Browser Store / AMO';
      autoInstallOpt.append(autoTitle, autoSub);

      autoInstallOpt.addEventListener('click', async (e) => {
        e.stopPropagation();
        menu.classList.add('hidden');
        try {
          installTriggerBtn.disabled = true;
          await sendMessage({
            type: 'AUTO_INSTALL_EXTENSION',
            item
          });
        } catch (err) {
          showAlert(err.message, true);
        } finally {
          installTriggerBtn.disabled = false;
        }
      });

      menu.appendChild(autoInstallOpt);

      const isFirefox = currentState?.browserEnv?.family === 'firefox';
      if (isFirefox && availableXpiByKey[item.key]) {
        const fileInstallOpt = document.createElement('button');
        fileInstallOpt.type = 'button';
        fileInstallOpt.className = 'install-dropdown-item';
        fileInstallOpt.title =
          'Install this extension from its .xpi package in your configured Git repository (xpi-files/)';
        const fileTitle = document.createElement('strong');
        fileTitle.textContent = 'Auto Install from File';
        const fileSub = document.createElement('span');
        fileSub.textContent = 'Install from Git repo xpi-files/';
        fileInstallOpt.append(fileTitle, fileSub);

        fileInstallOpt.addEventListener('click', async (e) => {
          e.stopPropagation();
          menu.classList.add('hidden');
          try {
            installTriggerBtn.disabled = true;
            const res = await sendMessage({
              type: 'AUTO_INSTALL_FROM_FILE',
              item
            });
            showAlert(
              `Installing "${item.name}" from ${res.target?.repo}/${res.target?.xpiFile}...`
            );
          } catch (err) {
            showAlert(err.message, true);
          } finally {
            installTriggerBtn.disabled = false;
          }
        });

        menu.appendChild(fileInstallOpt);
      }

      installTriggerBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (isFirefox && xpiCheckPromise) {
          await xpiCheckPromise;
        }
        const wasHidden = menu.classList.contains('hidden');
        for (const openMenu of document.querySelectorAll('.install-dropdown-menu')) {
          openMenu.classList.add('hidden');
        }
        if (wasHidden) {
          const rect = installTriggerBtn.getBoundingClientRect();
          if (rect.bottom + 110 > window.innerHeight) {
            menu.classList.add('drop-up');
          } else {
            menu.classList.remove('drop-up');
          }
          menu.classList.remove('hidden');
        }
      });

      dropdownWrap.append(installTriggerBtn, menu);
      actRow.appendChild(dropdownWrap);
    }

    const catalogBtn = document.createElement('button');
    catalogBtn.className = 'btn btn-sm btn-secondary';
    catalogBtn.textContent = 'Catalog JSON';
    catalogBtn.title = 'Show catalog object snippet for KNOWN_EXTENSIONS_CATALOG';
    catalogBtn.addEventListener('click', () => {
      openCatalogJsonModal(item);
    });
    actRow.appendChild(catalogBtn);

    const ignoreBtn = document.createElement('button');
    ignoreBtn.className = 'btn btn-sm btn-secondary';
    ignoreBtn.textContent = item.status === 'ignored' ? 'Unignore' : 'Ignore';
    ignoreBtn.title =
      item.status === 'ignored'
        ? 'Include this extension in cross-browser sync again'
        : 'Exclude this extension from cross-browser sync (saved in Gist)';
    ignoreBtn.addEventListener('click', async () => {
      try {
        const res = await sendMessage({
          type: 'TOGGLE_IGNORE_KEY',
          key: item.key
        });
        currentState = res.data;
        renderMatrix();
      } catch (err) {
        showAlert(err.message, true);
      }
    });
    actRow.appendChild(ignoreBtn);

    const removeGistBtn = document.createElement('button');
    removeGistBtn.className = 'btn btn-sm btn-danger';
    removeGistBtn.textContent = 'Remove from Gist';
    removeGistBtn.disabled = !item.inGist;
    removeGistBtn.title = item.inGist
      ? `Remove "${item.name}" from your GitHub Gist`
      : 'This extension is not currently saved in your GitHub Gist';
    removeGistBtn.addEventListener('click', async () => {
      try {
        removeGistBtn.disabled = true;
        const res = await sendMessage({
          type: 'REMOVE_FROM_GIST',
          key: item.key,
          name: item.name
        });
        currentState = res.data;
        renderMatrix();
        await refreshSyncLogs();
        showAlert(`Removed "${item.name}" from your GitHub Gist.`);
      } catch (err) {
        removeGistBtn.disabled = false;
        showAlert(err.message, true);
      }
    });
    actRow.appendChild(removeGistBtn);

    tdActions.appendChild(actRow);

    const tdGroups = createExtensionGroupsCell(item, groupsMap);

    tr.appendChild(tdExt);
    tr.appendChild(tdGroups);
    tr.appendChild(tdKey);
    tr.appendChild(tdIds);
    tr.appendChild(tdStatus);
    tr.appendChild(tdLocal);
    tr.appendChild(tdActions);
    els.matrixTbody.appendChild(tr);
  }
}

async function refreshSyncLogs() {
  try {
    const res = await sendMessage({ type: 'GET_SYNC_LOGS' });
    const logs = res.logs || [];
    els.syncLogList.replaceChildren();
    if (logs.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'muted';
      empty.textContent = 'No sync events recorded yet.';
      els.syncLogList.appendChild(empty);
      return;
    }
    for (const item of logs) {
      const row = document.createElement('div');
      row.className = 'log-item';
      const time = document.createElement('span');
      time.className = 'log-time';
      time.textContent = `${new Date(item.timestamp).toLocaleString()} [${(
        item.mode || 'sync'
      ).toUpperCase()}]`;
      const msg = document.createElement('span');
      msg.className = `log-msg ${item.status === 'error' ? 'error' : ''}`;
      msg.textContent = item.message;
      row.appendChild(time);
      row.appendChild(msg);
      els.syncLogList.appendChild(row);
    }
  } catch {
    // Ignore log load errors
  }
}

async function runSync(mode) {
  try {
    els.headerSyncBtn.disabled = true;
    els.headerPushBtn.disabled = true;
    els.headerPullBtn.disabled = true;

    const res = await sendMessage({ type: 'PERFORM_SYNC', mode });
    currentState = res.data;
    renderMatrix();
    refreshXpiAvailability();
    await refreshSyncLogs();

    const s = res.result?.summary;
    showAlert(
      `Sync (${mode}) complete! Total synced: ${s?.totalSynced ?? 0}, Local state updates: ${
        s?.toggledLocally ?? 0
      }, Missing on this browser: ${s?.missingCount ?? 0}.`
    );
  } catch (err) {
    showAlert(err.message, true);
    await refreshSyncLogs();
  } finally {
    els.headerSyncBtn.disabled = false;
    els.headerPushBtn.disabled = false;
    els.headerPullBtn.disabled = false;
  }
}

// Event Listeners
els.toggleTokenBtn.addEventListener('click', () => {
  const isPwd = els.githubToken.type === 'password';
  els.githubToken.type = isPwd ? 'text' : 'password';
  els.toggleTokenBtn.textContent = isPwd ? 'Hide' : 'Show';
});

els.toggleRepoTokenBtn.addEventListener('click', () => {
  const isPwd = els.gitRepoToken.type === 'password';
  els.gitRepoToken.type = isPwd ? 'text' : 'password';
  els.toggleRepoTokenBtn.textContent = isPwd ? 'Hide' : 'Show';
});

els.discoverGistBtn.addEventListener('click', async () => {
  const token = els.githubToken.value.trim();
  if (!token) {
    showAlert('Please enter your GitHub Personal Access Token first.', true);
    return;
  }
  try {
    els.discoverGistBtn.disabled = true;
    const res = await sendMessage({ type: 'VALIDATE_AND_DISCOVER_GIST', token });
    const { username, discoveredGistId } = res.info;
    if (discoveredGistId) {
      els.gistId.value = discoveredGistId;
      updateGistLink(discoveredGistId);
      await sendMessage({
        type: 'SAVE_SETTINGS',
        settings: { githubToken: token, gistId: discoveredGistId }
      });
      const refreshed = await sendMessage({ type: 'GET_DASHBOARD_STATE', refreshRemote: true });
      currentState = refreshed.data;
      renderMatrix();
      showAlert(
        `Authenticated as @${username} and auto-connected existing sync Gist (${discoveredGistId})!`
      );
    } else {
      showAlert(
        `Authenticated as @${username}! No existing sync Gist found yet — click "+ Create New Private Gist" to initialize one.`
      );
    }
  } catch (err) {
    showAlert(err.message, true);
  } finally {
    els.discoverGistBtn.disabled = false;
  }
});

els.createGistBtn.addEventListener('click', async () => {
  const token = els.githubToken.value.trim();
  if (!token) {
    showAlert('Please enter your GitHub Personal Access Token first.', true);
    return;
  }
  try {
    els.createGistBtn.disabled = true;
    const res = await sendMessage({ type: 'CREATE_GIST', token });
    els.gistId.value = res.created.gistId;
    updateGistLink(res.created.gistId);

    const refreshed = await sendMessage({ type: 'GET_DASHBOARD_STATE', refreshRemote: false });
    currentState = refreshed.data;
    renderMatrix();
    showAlert(`Created new private Gist (${res.created.gistId}) with your installed extensions!`);
  } catch (err) {
    showAlert(err.message, true);
  } finally {
    els.createGistBtn.disabled = false;
  }
});

els.saveGistBtn.addEventListener('click', async () => {
  try {
    const githubToken = els.githubToken.value.trim();
    const gistId = els.gistId.value.trim();
    const deviceName = els.deviceName.value.trim();
    const gitRepoUrl = els.gitRepoUrl.value.trim();
    const gitRepoToken = els.gitRepoToken.value.trim();
    const gitRepoBranch = els.gitRepoBranch.value.trim();

    await sendMessage({
      type: 'SAVE_SETTINGS',
      settings: { githubToken, gistId, deviceName, gitRepoUrl, gitRepoToken, gitRepoBranch }
    });
    updateGistLink(gistId);
    updateRepoLink(gitRepoUrl);

    const refreshed = await sendMessage({
      type: 'GET_DASHBOARD_STATE',
      refreshRemote: Boolean(githubToken && gistId)
    });
    currentState = refreshed.data;
    renderMatrix();
    refreshXpiAvailability();
    showAlert('Connection settings saved!');
  } catch (err) {
    showAlert(err.message, true);
  }
});

els.clearGistBtn.addEventListener('click', async () => {
  const token = els.githubToken.value.trim();
  const gistId = els.gistId.value.trim();
  if (!token || !gistId) {
    showAlert('GitHub Token and Gist ID are required to clear Gist data.', true);
    return;
  }
  const confirmed = window.confirm(
    'Are you sure you want to clear all saved extension data from your GitHub Gist? This will empty the remote sync list.'
  );
  if (!confirmed) return;

  try {
    els.clearGistBtn.disabled = true;
    const res = await sendMessage({
      type: 'CLEAR_GIST_DATA',
      token,
      gistId
    });
    currentState = res.data;
    renderMatrix();
    await refreshSyncLogs();
    showAlert('Cleared all saved extension data from your GitHub Gist.');
  } catch (err) {
    showAlert(err.message, true);
    await refreshSyncLogs();
  } finally {
    els.clearGistBtn.disabled = false;
  }
});

els.savePrefsBtn.addEventListener('click', async () => {
  try {
    const res = await sendMessage({
      type: 'SAVE_SETTINGS',
      settings: {
        autoSyncMinutes: Number(els.autoSyncMinutes.value) || 0,
        autoPushOnChange: els.autoPushOnChange.checked,
        autoApplyEnabledState: els.autoApplyEnabled.checked,
        syncDisabledExtensions: els.syncDisabledExtensions.checked,
        includeDevelopmentExtensions: els.includeDevExtensions.checked,
        exclusiveGroupActivation: els.exclusiveGroupActivation
          ? els.exclusiveGroupActivation.checked
          : true,
        syncActiveGroupsToGist: els.syncActiveGroupsGist
          ? els.syncActiveGroupsGist.checked
          : true
      }
    });
    currentState = res.data;
    renderMatrix();
    showAlert('Sync preferences saved!');
  } catch (err) {
    showAlert(err.message, true);
  }
});

els.headerSyncBtn.addEventListener('click', () => runSync('merge'));
els.headerPushBtn.addEventListener('click', () => runSync('push'));
els.headerPullBtn.addEventListener('click', () => runSync('pull'));

function openSettingsModal() {
  els.settingsModal.classList.remove('hidden');
}

function closeSettingsModal() {
  els.settingsModal.classList.add('hidden');
}

els.openSettingsModalBtn.addEventListener('click', openSettingsModal);
els.closeSettingsModalBtn.addEventListener('click', closeSettingsModal);

els.settingsModal.addEventListener('click', (e) => {
  if (e.target === els.settingsModal) {
    closeSettingsModal();
  }
});

function resetGroupForm() {
  editingGroupId = null;
  if (els.groupFormLabel) els.groupFormLabel.textContent = 'Create New Custom Group';
  if (els.newGroupNameInput) els.newGroupNameInput.value = '';
  if (els.newGroupColorInput) els.newGroupColorInput.value = '#3b82f6';
  if (els.saveGroupBtn) els.saveGroupBtn.textContent = '+ Save Group';
  if (els.cancelEditGroupBtn) els.cancelEditGroupBtn.classList.add('hidden');
}

function renderManageGroupsList() {
  if (!els.manageGroupsList || !currentState) return;
  const { comparison, settings } = currentState;
  const groupsMap = comparison?.groups || settings?.groups || {};
  const items = (comparison?.items || []).filter((i) => i.status !== 'ignored');
  const orderedGroups = getOrderedGroups(groupsMap);

  els.manageGroupsList.replaceChildren();

  for (const grp of orderedGroups) {
    const extCount = items.filter((item) => (item.groups || ['default']).includes(grp.id)).length;
    const row = document.createElement('div');
    row.className = 'manage-group-row';

    const info = document.createElement('div');
    info.className = 'manage-group-info';

    const dot = document.createElement('span');
    dot.className = 'group-dot';
    dot.style.backgroundColor = grp.color || '#3b82f6';

    const textCol = document.createElement('div');
    const nameEl = document.createElement('div');
    nameEl.className = 'manage-group-name';
    nameEl.textContent = grp.name;
    const metaEl = document.createElement('div');
    metaEl.className = 'manage-group-meta';
    metaEl.textContent = grp.isDefault
      ? `${extCount} extension(s) • System Default (Not affected by other groups)`
      : `${extCount} extension(s) • ID: ${grp.id}`;
    textCol.append(nameEl, metaEl);
    info.append(dot, textCol);

    const actions = document.createElement('div');
    actions.className = 'button-row';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn-secondary btn-sm';
    editBtn.textContent = 'Edit';
    editBtn.title = `Rename or change color for "${grp.name}"`;
    editBtn.addEventListener('click', () => {
      editingGroupId = grp.id;
      els.groupFormLabel.textContent = `Edit Group "${grp.name}" (${grp.id})`;
      els.newGroupNameInput.value = grp.name;
      els.newGroupColorInput.value = grp.color || '#3b82f6';
      els.saveGroupBtn.textContent = 'Update Group';
      els.cancelEditGroupBtn.classList.remove('hidden');
      els.newGroupNameInput.focus();
    });
    actions.appendChild(editBtn);

    if (!grp.isDefault) {
      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.className = 'btn btn-danger btn-sm';
      delBtn.textContent = 'Delete';
      delBtn.title = `Delete group "${grp.name}" (extensions only in this group will return to Default)`;
      delBtn.addEventListener('click', async () => {
        try {
          delBtn.disabled = true;
          const res = await sendMessage({
            type: 'DELETE_GROUP',
            groupId: grp.id
          });
          currentState = res.data;
          if (editingGroupId === grp.id) {
            resetGroupForm();
          }
          renderManageGroupsList();
          renderMatrix();
          showAlert(`Deleted group "${grp.name}".`);
        } catch (err) {
          delBtn.disabled = false;
          showAlert(err.message, true);
        }
      });
      actions.appendChild(delBtn);
    }

    row.append(info, actions);
    els.manageGroupsList.appendChild(row);
  }
}

function openManageGroupsModal() {
  resetGroupForm();
  renderManageGroupsList();
  els.manageGroupsModal.classList.remove('hidden');
}

function closeManageGroupsModal() {
  els.manageGroupsModal.classList.add('hidden');
  resetGroupForm();
}

if (els.openGroupsModalBtn) {
  els.openGroupsModalBtn.addEventListener('click', openManageGroupsModal);
}
if (els.closeGroupsModalBtn) {
  els.closeGroupsModalBtn.addEventListener('click', closeManageGroupsModal);
}
if (els.cancelEditGroupBtn) {
  els.cancelEditGroupBtn.addEventListener('click', resetGroupForm);
}
if (els.manageGroupsModal) {
  els.manageGroupsModal.addEventListener('click', (e) => {
    if (e.target === els.manageGroupsModal) {
      closeManageGroupsModal();
    }
  });
}
if (els.saveGroupBtn) {
  els.saveGroupBtn.addEventListener('click', async () => {
    const name = els.newGroupNameInput.value.trim();
    const color = els.newGroupColorInput.value || '#3b82f6';
    if (!name) {
      showAlert('Please enter a group name.', true);
      return;
    }
    try {
      els.saveGroupBtn.disabled = true;
      const res = await sendMessage({
        type: 'SAVE_GROUP',
        id: editingGroupId || undefined,
        name,
        color
      });
      currentState = res.data;
      resetGroupForm();
      renderManageGroupsList();
      renderMatrix();
      showAlert(`Saved group "${res.savedGroup?.name || name}"!`);
    } catch (err) {
      showAlert(err.message, true);
    } finally {
      els.saveGroupBtn.disabled = false;
    }
  });
}

document.addEventListener('click', () => {
  for (const openMenu of document.querySelectorAll('.install-dropdown-menu, .group-picker-menu')) {
    openMenu.classList.add('hidden');
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    for (const openMenu of document.querySelectorAll('.install-dropdown-menu, .group-picker-menu')) {
      openMenu.classList.add('hidden');
    }
    if (!els.settingsModal.classList.contains('hidden')) {
      closeSettingsModal();
    }
    if (!els.catalogJsonModal.classList.contains('hidden')) {
      closeCatalogJsonModal();
    }
    if (!els.matchAlternativeModal.classList.contains('hidden')) {
      closeMatchAlternativeModal();
    }
    if (els.manageGroupsModal && !els.manageGroupsModal.classList.contains('hidden')) {
      closeManageGroupsModal();
    }
  }
});

function populateExistingAlternativesDropdown(item, targetFamily) {
  els.altExistingSelect.replaceChildren();
  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = '— Select an existing extension to pair & merge —';
  els.altExistingSelect.appendChild(placeholder);

  const allItems = currentState?.comparison?.items || [];
  for (const candidate of allItems) {
    if (!candidate || candidate.key === item.key) continue;
    const candidateId =
      targetFamily === 'chromium'
        ? candidate.ids?.chromium
        : candidate.ids?.firefox ||
          (candidate.localId && currentState?.browserEnv?.family === 'firefox'
            ? candidate.localId
            : '');
    if (!candidateId) continue;

    const opt = document.createElement('option');
    opt.value = candidate.key;
    opt.dataset.extId = candidateId;
    opt.dataset.extName = candidate.name || candidate.key;
    opt.dataset.localId = candidate.localId || '';
    opt.dataset.storeUrl =
      (targetFamily === 'chromium'
        ? candidate.storeUrls?.chromium
        : candidate.storeUrls?.firefox) || '';
    opt.textContent = `${candidate.name} (${candidateId})`;
    els.altExistingSelect.appendChild(opt);
  }
}

function openMatchAlternativeModal(item, { initialCr, initialFf }) {
  activeAlternativeItem = item;
  els.matchAlternativeModalTitle.textContent = `Match Equivalent Alternative — ${item.name}`;

  const defaultTarget = !initialFf && initialCr ? 'firefox' : !initialCr && initialFf ? 'chromium' : 'firefox';
  els.altTargetFamily.value = defaultTarget;

  const updateTargetFields = () => {
    const fam = els.altTargetFamily.value;
    populateExistingAlternativesDropdown(item, fam);
    const currentId = fam === 'chromium' ? initialCr : initialFf;
    const currentUrl =
      fam === 'chromium' ? item.storeUrls?.chromium : item.storeUrls?.firefox;
    els.altIdInput.value = item.equivalentAlternative ? currentUrl || currentId || '' : '';
    els.altIdInput.placeholder =
      fam === 'chromium'
        ? 'Paste Chrome Web Store URL or 32-char Chromium ID...'
        : 'Paste Firefox Add-ons (AMO) URL or Add-on GUID/slug...';
  };

  updateTargetFields();
  els.altNameInput.value = item.alternativeName || '';
  els.altStoreSearchInput.value = item.alternativeName || item.name || '';
  els.altStoreResults.replaceChildren();
  els.altStoreResults.classList.add('hidden');

  if (item.equivalentAlternative) {
    els.clearAlternativeBtn.classList.remove('hidden');
  } else {
    els.clearAlternativeBtn.classList.add('hidden');
  }

  els.altTargetFamily.onchange = updateTargetFields;
  els.matchAlternativeModal.classList.remove('hidden');
}

function closeMatchAlternativeModal() {
  els.matchAlternativeModal.classList.add('hidden');
  activeAlternativeItem = null;
}

els.closeAlternativeModalBtn.addEventListener('click', closeMatchAlternativeModal);
els.cancelAlternativeBtn.addEventListener('click', closeMatchAlternativeModal);
els.matchAlternativeModal.addEventListener('click', (e) => {
  if (e.target === els.matchAlternativeModal) {
    closeMatchAlternativeModal();
  }
});

els.altExistingSelect.addEventListener('change', () => {
  const selectedOpt = els.altExistingSelect.selectedOptions?.[0];
  if (!selectedOpt || !selectedOpt.value) return;
  els.altIdInput.value = selectedOpt.dataset.storeUrl || selectedOpt.dataset.extId || '';
  els.altNameInput.value = selectedOpt.dataset.extName || '';
});

els.altStoreSearchBtn.addEventListener('click', async () => {
  const query = els.altStoreSearchInput.value.trim();
  const family = els.altTargetFamily.value;
  if (!query) return;

  try {
    els.altStoreSearchBtn.disabled = true;
    els.altStoreSearchBtn.textContent = 'Searching...';
    const res = await sendMessage({
      type: 'SEARCH_STORE_ALTERNATIVES',
      query,
      family
    });
    const results = res.results || [];
    els.altStoreResults.replaceChildren();
    els.altStoreResults.classList.remove('hidden');

    if (results.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'alt-search-item muted';
      empty.textContent = 'No matching store extensions found.';
      els.altStoreResults.appendChild(empty);
      return;
    }

    for (const cand of results) {
      const row = document.createElement('div');
      row.className = 'alt-search-item';

      const info = document.createElement('div');
      info.className = 'alt-search-info';
      const title = document.createElement('div');
      title.className = 'alt-search-title';
      title.textContent = cand.name;
      const sub = document.createElement('div');
      sub.className = 'alt-search-sub';
      sub.textContent = cand.id;
      info.append(title, sub);

      const selectBtn = document.createElement('button');
      selectBtn.type = 'button';
      selectBtn.className = 'btn btn-secondary btn-sm';
      selectBtn.textContent = 'Select';
      selectBtn.title = `Use "${cand.name}" (${cand.id}) as the equivalent alternative`;
      selectBtn.addEventListener('click', () => {
        els.altIdInput.value = cand.storeUrl || cand.id;
        els.altNameInput.value = cand.name;
      });

      row.append(info, selectBtn);
      els.altStoreResults.appendChild(row);
    }
  } catch (err) {
    showAlert(err.message, true);
  } finally {
    els.altStoreSearchBtn.disabled = false;
    els.altStoreSearchBtn.textContent = 'Search Store';
  }
});

els.saveAlternativeBtn.addEventListener('click', async () => {
  if (!activeAlternativeItem) return;
  const targetFamily = els.altTargetFamily.value;
  const alternativeInput = els.altIdInput.value.trim();
  const alternativeName = els.altNameInput.value.trim();
  const selectedOpt = els.altExistingSelect.selectedOptions?.[0];
  const mergeSourceKey = selectedOpt?.value || '';
  const mergeSourceLocalId = selectedOpt?.dataset?.localId || '';

  if (!alternativeInput) {
    showAlert('Please enter or select an equivalent extension Store URL or ID.', true);
    return;
  }

  try {
    els.saveAlternativeBtn.disabled = true;
    const itemName = activeAlternativeItem.name;
    const res = await sendMessage({
      type: 'SAVE_EQUIVALENT_ALTERNATIVE',
      key: activeAlternativeItem.key,
      targetFamily,
      alternativeInput,
      alternativeName,
      mergeSourceKey,
      mergeSourceLocalId,
      clearAlternative: false
    });
    currentState = res.data;
    closeMatchAlternativeModal();
    renderMatrix();
    refreshXpiAvailability();
    showAlert(
      `Matched "${itemName}" with equivalent alternative${
        res.savedAlternative?.alternativeName ? ` "${res.savedAlternative.alternativeName}"` : ''
      } and flagged as Equivalent Alternative!`
    );
  } catch (err) {
    showAlert(err.message, true);
  } finally {
    els.saveAlternativeBtn.disabled = false;
  }
});

els.clearAlternativeBtn.addEventListener('click', async () => {
  if (!activeAlternativeItem) return;
  try {
    els.clearAlternativeBtn.disabled = true;
    const itemName = activeAlternativeItem.name;
    const res = await sendMessage({
      type: 'SAVE_EQUIVALENT_ALTERNATIVE',
      key: activeAlternativeItem.key,
      clearAlternative: true
    });
    currentState = res.data;
    closeMatchAlternativeModal();
    renderMatrix();
    showAlert(`Removed Equivalent Alternative flag from "${itemName}".`);
  } catch (err) {
    showAlert(err.message, true);
  } finally {
    els.clearAlternativeBtn.disabled = false;
  }
});

async function openCatalogJsonModal(item) {
  const initialEntry = buildCatalogEntry(item);
  els.catalogJsonModalTitle.textContent = `Catalog Entry — ${item.name}`;
  els.catalogJsonPre.textContent = formatCatalogEntrySnippet(initialEntry);
  els.copyCatalogJsonBtn.textContent = 'Copy to Clipboard';
  els.catalogJsonModal.classList.remove('hidden');

  // Also resolve any missing firefoxSlug / firefoxId / chromiumId from store APIs in background
  try {
    const res = await sendMessage({
      type: 'RESOLVE_CATALOG_SNIPPET',
      item
    });
    if (res?.snippet && !els.catalogJsonModal.classList.contains('hidden')) {
      els.catalogJsonPre.textContent = res.snippet;
    }
  } catch {
    // Keep initial snippet on error
  }
}

function closeCatalogJsonModal() {
  els.catalogJsonModal.classList.add('hidden');
}

els.closeCatalogJsonModalBtn.addEventListener('click', closeCatalogJsonModal);
els.catalogJsonModal.addEventListener('click', (e) => {
  if (e.target === els.catalogJsonModal) {
    closeCatalogJsonModal();
  }
});

els.copyCatalogJsonBtn.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(els.catalogJsonPre.textContent);
    els.copyCatalogJsonBtn.textContent = 'Copied!';
    setTimeout(() => {
      els.copyCatalogJsonBtn.textContent = 'Copy to Clipboard';
    }, 2000);
  } catch (err) {
    showAlert(`Failed to copy: ${err.message}`, true);
  }
});

els.refreshRemoteBtn.addEventListener('click', async () => {
  try {
    els.refreshRemoteBtn.disabled = true;
    const res = await sendMessage({ type: 'GET_DASHBOARD_STATE', refreshRemote: true });
    currentState = res.data;
    renderMatrix();
    refreshXpiAvailability();
    showAlert('Refreshed remote state from GitHub Gist.');
  } catch (err) {
    showAlert(err.message, true);
  } finally {
    els.refreshRemoteBtn.disabled = false;
  }
});

els.matrixSearch.addEventListener('input', () => renderMatrix());

els.matrixInstallMissingBtn.addEventListener('click', async () => {
  if (!currentState) return;
  const missing = currentState.comparison.items.filter((i) => i.status === 'missing');
  if (missing.length === 0) return;
  try {
    els.matrixInstallMissingBtn.disabled = true;
    await sendMessage({
      type: 'AUTO_INSTALL_ALL_MISSING',
      items: missing
    });
  } catch (err) {
    showAlert(err.message, true);
  } finally {
    els.matrixInstallMissingBtn.disabled = false;
  }
});

// Export Settings
els.exportSettingsBtn.addEventListener('click', () => {
  try {
    const baseSettings = currentState?.settings || {};
    const exportedSettings = {
      ...baseSettings,
      githubToken: els.githubToken.value.trim(),
      gistId: els.gistId.value.trim(),
      deviceName: els.deviceName.value.trim(),
      gitRepoUrl: els.gitRepoUrl.value.trim(),
      gitRepoToken: els.gitRepoToken.value.trim(),
      gitRepoBranch: els.gitRepoBranch.value.trim(),
      autoSyncMinutes: Number(els.autoSyncMinutes.value) || 0,
      autoPushOnChange: els.autoPushOnChange.checked,
      autoApplyEnabledState: els.autoApplyEnabled.checked,
      syncDisabledExtensions: els.syncDisabledExtensions.checked,
      includeDevelopmentExtensions: els.includeDevExtensions.checked,
      exclusiveGroupActivation: els.exclusiveGroupActivation
        ? els.exclusiveGroupActivation.checked
        : true,
      syncActiveGroupsToGist: els.syncActiveGroupsGist
        ? els.syncActiveGroupsGist.checked
        : true
    };

    const payload = {
      app: 'extensions-cross_browser-sync-settings',
      exportedAt: new Date().toISOString(),
      settings: exportedSettings
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `extensions-cross_browser-sync-settings-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showAlert('Exported all settings to JSON file.');
  } catch (err) {
    showAlert(`Failed to export settings: ${err.message}`, true);
  }
});

// Import Settings
els.importSettingsInput.addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    const raw = JSON.parse(text);
    const incoming =
      raw && typeof raw.settings === 'object' && raw.settings !== null ? raw.settings : raw;

    if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) {
      throw new Error('Invalid settings JSON file.');
    }

    const allowedKeys = [
      'githubToken',
      'gistId',
      'gitRepoUrl',
      'gitRepoToken',
      'gitRepoBranch',
      'deviceName',
      'autoSyncMinutes',
      'autoPushOnChange',
      'autoApplyEnabledState',
      'syncDisabledExtensions',
      'includeDevelopmentExtensions',
      'exclusiveGroupActivation',
      'syncActiveGroupsToGist',
      'groups',
      'extensionGroups',
      'activeGroupIds',
      'ignoredKeys',
      'customMappings',
      'customBrowserIds'
    ];

    const nextSettings = {};
    for (const k of allowedKeys) {
      if (k in incoming) {
        nextSettings[k] = incoming[k];
      }
    }

    if (Object.keys(nextSettings).length === 0) {
      throw new Error('No recognized settings keys found in the imported file.');
    }

    const saveRes = await sendMessage({
      type: 'SAVE_SETTINGS',
      settings: nextSettings
    });
    currentState = saveRes.data;
    populateSettingsForm(currentState.settings, currentState.browserEnv);

    if (currentState.settings.githubToken && currentState.settings.gistId) {
      const refreshed = await sendMessage({
        type: 'GET_DASHBOARD_STATE',
        refreshRemote: true
      });
      currentState = refreshed.data;
    }

    renderMatrix();
    refreshXpiAvailability();
    showAlert('Imported and saved all settings successfully!');
  } catch (err) {
    showAlert(`Failed to import settings: ${err.message}`, true);
  } finally {
    e.target.value = '';
  }
});

// Export JSON
els.exportJsonBtn.addEventListener('click', async () => {
  try {
    const payload = await buildInitialPayloadFromLocal();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `extensions-cross_browser-sync-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    showAlert(err.message, true);
  }
});

// Import JSON
els.importJsonInput.addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    const parsed = normalizeSyncPayload(JSON.parse(text));
    const res = await sendMessage({
      type: 'IMPORT_PAYLOAD_CACHE',
      payload: parsed
    });
    currentState = res.data;
    renderMatrix();
    showAlert(
      `Imported ${Object.keys(parsed.extensions).length} extensions into comparison view. Click "Pull ↓" or "Sync Now" to apply.`
    );
  } catch (err) {
    showAlert(`Failed to import JSON: ${err.message}`, true);
  } finally {
    e.target.value = '';
  }
});

// Initialize page
(async () => {
  try {
    const res = await sendMessage({ type: 'GET_DASHBOARD_STATE', refreshRemote: false });
    currentState = res.data;
    populateSettingsForm(currentState.settings, currentState.browserEnv);
    renderMatrix();
    refreshXpiAvailability();
    await refreshSyncLogs();

    // Automatically discover any missing other-browser IDs & store links in the background
    const incompleteItems = (currentState?.comparison?.items || []).filter(
      (i) => i.status !== 'ignored' && (!i.ids?.chromium || !i.ids?.firefox)
    );
    if (incompleteItems.length > 0) {
      sendMessage({
        type: 'ENRICH_DASHBOARD_IDS',
        items: incompleteItems
      })
        .then((enrichRes) => {
          if (enrichRes?.changed && enrichRes.data) {
            currentState = enrichRes.data;
            renderMatrix();
          }
        })
        .catch(() => {
          // Non-blocking background enrichment
        });
    }
  } catch (err) {
    showAlert(err.message, true);
  }
})();

